module.exports=[44692,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28postAuth%29_settings_page_actions_c2f1f563.js.map
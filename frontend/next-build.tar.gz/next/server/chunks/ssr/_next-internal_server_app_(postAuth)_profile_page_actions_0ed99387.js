module.exports=[90252,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28postAuth%29_profile_page_actions_0ed99387.js.map
var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/[root-of-the-server]__f9f857e0._.js")
R.c("server/chunks/node_modules_formdata-node_lib_esm_File_ccf0a600.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__c28a1074._.js")
R.c("server/chunks/_next-internal_server_app_api_chat_route_actions_ac0c75e3.js")
R.m(61378)
module.exports=R.m(61378).exports

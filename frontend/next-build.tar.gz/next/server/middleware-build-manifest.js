globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/23da134c06298c6e.js",
    "static/chunks/8b4c52e426985d12.js",
    "static/chunks/32b3bef3019f2e82.js",
    "static/chunks/30ea11065999f7ac.js",
    "static/chunks/turbopack-e06851184050c6b8.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];